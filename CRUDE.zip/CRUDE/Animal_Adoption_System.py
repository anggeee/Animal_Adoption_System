from tkinter import *
from tkinter import ttk
from tkinter import messagebox

data =[]
class Animal:
    def __init__(self, name, breed,  status):
        self.name = name
        self.breed = breed
        self.status = status

    def getName(self):
        return self.name


    def getBreed(self):
        return self.breed


    def getStatus(self):
        return self.status


#Frame
root = Tk()
root.resizable(0,0)
root.title("Animal Adoption System")
#root.geometry("750x500")
root.configure(background = '#ffe6e6')

#Photos
photo_add = PhotoImage(file = r"C:\Users\lenovo\Desktop\CRUD\add.png")
photo_delete = PhotoImage(file = r"C:\Users\lenovo\Desktop\CRUD\delete.png")
photo_update = PhotoImage(file = r"C:\Users\lenovo\Desktop\CRUD\update.png")
photo_exit = PhotoImage(file = r"C:\Users\lenovo\Desktop\CRUD\exit.png")


def addAnimals():
    
    tv.insert('' ,'end', text = e1.get(), values=(e1.get(), e2.get(), e3.get()))
    messagebox.showinfo("Information", "Added")
    
    e1.delete(0, 'end')
    e2.delete(0, 'end')
    e3.delete(0, 'end')
 
def delete_items():
    confirm = messagebox.askquestion("Delete", "Are you sure to delete this data ?")
    if confirm == "yes":
        selected_items = tv.selection()[0]
        tv.delete(selected_items)
    else:
        print(" ")

    
def dataExit():
    i = messagebox.askquestion("Warning"," Are you sure to leave this page? ")
    if i == "yes":
        root.destroy()
        #messagebox.showinfo("Animal Adoption System","Thank you")
    else:
        print(" ")

def UpdateData():
    selected_items = tv.selection()[0]
    tv.item(selected_items, text = e1.get(),values=(e1.get() , e2.get(), e3.get()))
    

#Label
Label(root, text = "Animal Adoption System",bg = '#ffe6e6', font = "Calibri 16 bold").grid( row= 1, column = 1)

Label(root, text = "Name of Animal", bg = '#ffe6e6', font = "Calibri 14 bold").grid(row =2, column = 0, padx = 10, pady= 10)
Label(root, text = "Breed", bg = '#ffe6e6', font = "Calibri 14 bold").grid(row =3, column = 0, padx = 3, pady= 10)
Label(root, text = "Status", bg = '#ffe6e6', font = "Calibri 14 bold").grid(row =4, column = 0, padx =3, pady= 10)

#Textbox
e1 = Entry(root, width = 30)
e1.grid(row = 2, column = 1, padx = 5, pady = 10)
e2 = Entry (root, width = 30)
e2.grid(row = 3,column = 1, padx = 5, pady =10)
e3 = Entry (root, width = 30)
e3.grid(row = 4, column = 1, padx =5, pady = 10)

#Button
btn_add = Button(root, text = "Add" ,image = photo_add ,width = 50,height = 50 ,command = addAnimals).grid(row = 6, column = 0, padx =0, pady = 3, sticky = E)
btn_remove = Button(root, text = "Delete", image = photo_delete, width=  50, height = 50 ,command = delete_items).grid(row = 6, column = 1, padx =1, pady= 3, sticky = W)
btn_update = Button(root, text = "Update",image = photo_update ,width = 50,height = 50, command = UpdateData).grid(row = 6, column = 2, padx =1, pady= 3)
btn_exit = Button(root, text = "Exit",image = photo_exit ,width = 50,height = 50, command = dataExit).grid(row = 6, column = 3, padx = 1, pady =5)

#Table

tv = ttk.Treeview(root, column = ("Name", "Breed", "Status"), show = "headings")
tv.heading('#1', text = 'Name')
tv.heading('#2', text = 'Breed')
tv.heading('#3', text = 'Status')
tv.grid(row = 50, column =1 ,padx = 10, pady = 10)


root.mainloop()




